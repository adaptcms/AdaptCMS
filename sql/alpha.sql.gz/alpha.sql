-- phpMyAdmin SQL Dump
-- version 3.5.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Oct 14, 2012 at 07:56 PM
-- Server version: 5.1.63-0ubuntu0.11.10.1
-- PHP Version: 5.3.6-13ubuntu3.9

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `alpha`
--

-- --------------------------------------------------------

--
-- Table structure for table `articles`
--

CREATE TABLE IF NOT EXISTS `articles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) DEFAULT NULL,
  `slug` varchar(100) DEFAULT NULL,
  `tags` longtext,
  `related_articles` longtext NOT NULL,
  `user_id` int(11) DEFAULT '0',
  `category_id` int(11) DEFAULT '0',
  `status` int(3) DEFAULT '0',
  `publish_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `deleted_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=16 ;

--
-- Dumping data for table `articles`
--

INSERT INTO `articles` (`id`, `title`, `slug`, `tags`, `related_articles`, `user_id`, `category_id`, `status`, `publish_time`, `created`, `modified`, `deleted_time`) VALUES
(1, 'halo 4 bud', 'halo_4_bud', NULL, '', 7, 3, 1, '0000-00-00 00:00:00', '2012-06-09 23:39:08', '2012-09-02 09:33:37', '0000-00-00 00:00:00'),
(5, 'The Matrix', 'the-matrix', NULL, '["14"]', 7, 6, 1, '0000-00-00 00:00:00', '2012-08-05 22:57:10', '2012-10-07 20:47:33', '0000-00-00 00:00:00'),
(14, 'The Campaign', 'the-campaign', '["will-ferrell","funny","rated-r","crude","zach-galifianakis"]', '["1","5"]', 7, 6, 1, '0000-00-00 00:00:00', '2012-08-30 23:20:41', '2012-10-07 21:09:46', '0000-00-00 00:00:00'),
(15, 'test65', 'test65', NULL, '["1","5"]', 7, 6, 1, '0000-00-00 00:00:00', '2012-10-07 21:59:54', '2012-10-07 22:18:07', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `article_values`
--

CREATE TABLE IF NOT EXISTS `article_values` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `article_id` int(11) DEFAULT '0',
  `field_id` int(11) DEFAULT '0',
  `data` text,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=74 ;

--
-- Dumping data for table `article_values`
--

INSERT INTO `article_values` (`id`, `article_id`, `field_id`, `data`) VALUES
(1, 1, 12, 'there'),
(12, 1, 11, 'new_one'),
(3, 1, 13, 'Yes'),
(13, 1, 16, 'image.jpg'),
(6, 1, 17, 'http://www.website.com'),
(7, 1, 18, '1111'),
(8, 1, 19, 'abc@google.com'),
(9, 1, 20, '02/05/2005'),
(34, 1, 14, '["Male"]'),
(23, 2, 22, 'PC'),
(24, 3, 23, '2012'),
(39, 5, 23, '2001'),
(40, 5, 24, '["Drama","Action","Sci-Fi"]'),
(45, 5, 25, 'Pond.png'),
(68, 14, 25, 'campaign2012_1.jpg'),
(69, 14, 23, '2012'),
(70, 1, 26, '["yes","no"]'),
(71, 14, 24, '["Comedy"]'),
(72, 15, 23, '2222'),
(73, 15, 24, '["Comedy"]');

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE IF NOT EXISTS `categories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) DEFAULT NULL,
  `slug` varchar(100) DEFAULT NULL,
  `created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `deleted_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=8 ;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `title`, `slug`, `created`, `modified`, `deleted_time`) VALUES
(2, 'Reviews', 'reviews', '2012-06-03 22:18:57', '2012-06-05 23:41:40', '0000-00-00 00:00:00'),
(3, 'News', 'news', '2012-06-03 22:19:02', '2012-06-05 23:41:47', '0000-00-00 00:00:00'),
(6, 'Movies', 'movies', '2012-06-05 23:41:52', '2012-06-05 23:41:56', '0000-00-00 00:00:00'),
(7, 'Games', 'games', '2012-07-15 13:54:36', '2012-07-15 13:54:39', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `comments`
--

CREATE TABLE IF NOT EXISTS `comments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `article_id` int(11) DEFAULT '0',
  `user_id` int(11) DEFAULT '0',
  `comment_text` text,
  `author_name` varchar(255) DEFAULT NULL,
  `author_email` varchar(255) DEFAULT NULL,
  `author_website` varchar(255) DEFAULT NULL,
  `author_ip` varchar(255) DEFAULT NULL,
  `status` int(3) DEFAULT '0',
  `created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `deleted_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `components`
--

CREATE TABLE IF NOT EXISTS `components` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) DEFAULT NULL,
  `model_title` varchar(255) DEFAULT NULL,
  `module_active` int(1) NOT NULL DEFAULT '0',
  `is_plugin` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=17 ;

--
-- Dumping data for table `components`
--

INSERT INTO `components` (`id`, `title`, `model_title`, `module_active`, `is_plugin`) VALUES
(1, 'Articles', 'Article', 1, 0),
(2, 'Modules', 'Module', 0, 0),
(3, 'Categories', 'Category', 1, 0),
(4, 'Files', 'File', 1, 0),
(5, 'Fields', 'Field', 0, 0),
(6, 'Templates', 'Template', 0, 0),
(7, 'Themes', 'Theme', 0, 0),
(8, 'Polls', 'Poll', 1, 1),
(9, 'Users', 'User', 0, 0),
(10, 'Pages', 'Page', 0, 0),
(11, 'Roles', 'Role', 0, 0),
(12, 'Settings', 'Setting', 0, 0),
(13, 'Setting Values', 'SettingValue', 0, 0),
(14, 'Themes', 'Theme', 0, 0),
(16, 'Support Tickets', 'Ticket', 0, 1);

-- --------------------------------------------------------

--
-- Table structure for table `fields`
--

CREATE TABLE IF NOT EXISTS `fields` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) DEFAULT NULL,
  `label` varchar(255) NOT NULL,
  `field_order` int(11) NOT NULL DEFAULT '0',
  `category_id` int(11) DEFAULT '0',
  `field_type` varchar(255) DEFAULT NULL,
  `description` text,
  `field_options` longtext,
  `field_limit_min` int(11) NOT NULL DEFAULT '0',
  `field_limit_max` int(11) NOT NULL DEFAULT '0',
  `required` int(1) NOT NULL DEFAULT '0',
  `rules` text,
  `created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `deleted_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=27 ;

--
-- Dumping data for table `fields`
--

INSERT INTO `fields` (`id`, `title`, `label`, `field_order`, `category_id`, `field_type`, `description`, `field_options`, `field_limit_min`, `field_limit_max`, `required`, `rules`, `created`, `modified`, `deleted_time`) VALUES
(1, 'summary', 'summary', 0, 2, 'textarea', 'You ought to enter a short summary of the news article.', '', 0, 0, 1, NULL, '2012-06-03 23:24:24', '2012-06-10 16:14:47', '0000-00-00 00:00:00'),
(12, 'basd', 'basd', 0, 3, 'dropdown', '', '["this","that","there"]', 0, 0, 0, '["required: false,"]', '2012-06-09 21:36:18', '2012-08-12 22:52:30', '0000-00-00 00:00:00'),
(11, 'test', 'test', 0, 3, 'text', '', '', 2, 10, 1, '["required: true,","minlength: 2,","maxlength: 10,"]', '2012-06-09 21:35:49', '2012-07-01 15:09:26', '0000-00-00 00:00:00'),
(13, 'radio_guy', 'radio_guy', 0, 3, 'radio', '', '["Yes","No"]', 0, 0, 1, '["required: true,"]', '2012-06-09 21:36:32', '2012-09-01 22:09:05', '0000-00-00 00:00:00'),
(14, 'gender', 'gender', 0, 3, 'dropdown', '', '["Male","Female"]', 0, 0, 0, '["required: false,"]', '2012-06-09 21:37:02', '2012-08-12 21:04:33', '0000-00-00 00:00:00'),
(15, 'here_s_a_file', 'here_s_a_file', 0, 3, 'file', '', '', 0, 0, 0, NULL, '2012-06-09 21:37:41', '2012-06-10 16:14:56', '0000-00-00 00:00:00'),
(16, 'image', 'image', 0, 3, 'img', '', '', 0, 0, 0, NULL, '2012-06-09 21:38:31', '2012-06-10 16:15:06', '0000-00-00 00:00:00'),
(17, 'link', 'link', 0, 3, 'url', '', '', 0, 0, 0, 'required: false,url: true,', '2012-06-09 21:39:16', '2012-06-10 17:45:51', '0000-00-00 00:00:00'),
(18, 'year', 'year', 0, 3, 'num', '', '', 0, 0, 0, 'required: false,number: true,', '2012-06-09 21:39:24', '2012-06-10 17:46:07', '0000-00-00 00:00:00'),
(19, 'email', 'Email', 0, 3, 'email', '', '', 0, 0, 0, 'required: false,email: true,', '2012-06-09 21:39:34', '2012-06-10 17:45:59', '0000-00-00 00:00:00'),
(20, 'date_selector', 'date_selector', 0, 3, 'date', '', '', 0, 0, 0, NULL, '2012-06-09 21:39:44', '2012-06-10 16:14:38', '0000-00-00 00:00:00'),
(21, 'this_is_a_new_field', 'This is a field', 0, 3, 'textarea', '', '', 0, 0, 0, '["required: false,"]', '2012-06-10 16:10:14', '2012-07-01 14:45:16', '0000-00-00 00:00:00'),
(22, 'system', 'system', 0, 7, 'dropdown', '', '["PC","360","Wii","Playstation 3"]', 0, 0, 1, '["required: true,"]', '2012-06-30 23:34:32', '2012-08-12 21:43:00', '0000-00-00 00:00:00'),
(23, 'release-year', 'Release Year', 0, 6, 'num', '', '', 4, 4, 1, '["required: true,","minlength: 4,","maxlength: 4,","number: true,"]', '2012-07-15 14:15:19', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(24, 'genres', 'Genres', 0, 6, 'multi-dropdown', '', '["Drama","Action","Comedy","Sci-Fi"]', 0, 0, 1, '["required: true,"]', '2012-08-05 22:36:49', '2012-09-02 09:08:42', '0000-00-00 00:00:00'),
(25, 'boxart', 'Boxart', 0, 6, 'file', '', '', 0, 0, 0, '["required: false,"]', '2012-08-07 14:28:37', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(26, 'test_checkbox', 'test checkbox', 0, 3, 'check', '', '["yes","no","maybe so"]', 0, 0, 1, '["required: true,"]', '2012-09-01 21:56:17', '2012-09-01 22:08:57', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `files`
--

CREATE TABLE IF NOT EXISTS `files` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `filename` varchar(255) DEFAULT NULL,
  `dir` varchar(255) DEFAULT NULL,
  `filesize` varchar(255) NOT NULL,
  `mimetype` varchar(255) NOT NULL,
  `caption` varchar(255) DEFAULT NULL,
  `media_id` int(11) DEFAULT '0',
  `created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `deleted_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=36 ;

--
-- Dumping data for table `files`
--

INSERT INTO `files` (`id`, `filename`, `dir`, `filesize`, `mimetype`, `caption`, `media_id`, `created`, `modified`, `deleted_time`) VALUES
(18, 'Pond.png', 'uploads/', '337778', 'image/png', NULL, 0, '2012-08-12 14:31:50', '2012-08-12 14:33:19', '0000-00-00 00:00:00'),
(17, 'Pond_Beard_Wives_Denim.jpg', 'uploads/', '213086', 'image/jpeg', NULL, 0, '2012-08-12 14:17:58', '2012-08-12 14:17:58', '0000-00-00 00:00:00'),
(16, 'led_zeppelin_houses_of_the_holy.jpg', 'uploads/', '819463', 'image/jpeg', NULL, 0, '2012-08-12 13:48:24', '2012-08-12 14:15:53', '0000-00-00 00:00:00'),
(23, 'campaign2012_1.jpg', 'uploads/', '28230', 'image/jpeg', NULL, 0, '2012-08-30 23:21:08', '2012-08-30 23:21:08', '0000-00-00 00:00:00'),
(26, 'robots2.txt', 'uploads/', '181', 'text/plain', 'Robotss', 0, '2012-09-23 17:58:20', '2012-09-23 20:14:24', '0000-00-00 00:00:00'),
(35, NULL, NULL, '', '', NULL, 0, '2012-10-07 22:03:55', '2012-10-07 22:03:55', '0000-00-00 00:00:00'),
(34, 'adaptcms3_logo.png', 'uploads/', '4477', 'image/png', 'AdaptCMS Logo', 0, '2012-10-06 18:34:05', '2012-10-06 18:34:05', '0000-00-00 00:00:00'),
(33, 'styless.css', 'uploads/', '6', 'text/css', 'A style sheets', 0, '2012-10-06 18:31:49', '2012-10-06 18:31:49', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `logs`
--

CREATE TABLE IF NOT EXISTS `logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `data` longtext,
  `user_id` int(11) NOT NULL,
  `ip_address` varchar(30) NOT NULL,
  `plugin` varchar(55) DEFAULT NULL,
  `controller` varchar(55) NOT NULL,
  `action` varchar(55) NOT NULL,
  `action_id` int(11) NOT NULL DEFAULT '0',
  `date` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `media`
--

CREATE TABLE IF NOT EXISTS `media` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) DEFAULT NULL,
  `created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `deleted_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `messages`
--

CREATE TABLE IF NOT EXISTS `messages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `box_slug` varchar(100) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `message` text,
  `sender_user_id` int(11) DEFAULT '0',
  `receiver_user_id` int(11) DEFAULT '0',
  `created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `deleted_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `modules`
--

CREATE TABLE IF NOT EXISTS `modules` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `component_id` int(11) NOT NULL,
  `template_id` int(11) NOT NULL,
  `location` longtext NOT NULL,
  `limit` int(11) NOT NULL,
  `settings` longtext NOT NULL,
  `created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `deleted_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `modules`
--

INSERT INTO `modules` (`id`, `title`, `component_id`, `template_id`, `location`, `limit`, `settings`, `created`, `modified`, `deleted_time`) VALUES
(1, 'latest-articles-stuff-2', 1, 77, '["pages|display|contact-us","categories|view|news"]', 3, '', '2012-10-13 21:08:21', '2012-10-14 18:47:20', '2012-10-14 18:47:20'),
(2, 'show-poll', 8, 78, '["*"]', 1, '', '2012-10-13 23:19:41', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(3, 'categories-list', 3, 23, '["*"]', 5, '', '2012-10-14 18:36:01', '0000-00-00 00:00:00', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `pages`
--

CREATE TABLE IF NOT EXISTS `pages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) DEFAULT NULL,
  `slug` varchar(100) DEFAULT NULL,
  `content` text,
  `created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `deleted_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `pages`
--

INSERT INTO `pages` (`id`, `title`, `slug`, `content`, `created`, `modified`, `deleted_time`) VALUES
(1, 'just a pageas', 'just_a_pageas', '<p>ok here is content!</p>', '2012-06-05 23:28:03', '2012-06-10 18:36:17', '0000-00-00 00:00:00'),
(2, 'test', 'test', 'adsasd', '2012-06-05 23:38:20', '2012-06-05 23:38:23', '0000-00-00 00:00:00'),
(3, 'what about ! this?', 'what_about_this', '', '2012-06-05 23:38:29', '2012-06-05 23:38:37', '0000-00-00 00:00:00'),
(4, 'Contact Us', 'contact-us', '<p>hey send me an email yo</p>', '2012-07-12 22:36:28', '2012-10-03 21:52:42', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `permissions`
--

CREATE TABLE IF NOT EXISTS `permissions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(50) DEFAULT NULL,
  `role_id` int(11) NOT NULL,
  `plugin` varchar(50) DEFAULT NULL,
  `controller` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=47 ;

--
-- Dumping data for table `permissions`
--

INSERT INTO `permissions` (`id`, `title`, `role_id`, `plugin`, `controller`) VALUES
(6, 'Admin Roles', 1, NULL, 'roles'),
(8, 'Admin Users', 1, NULL, 'users'),
(17, 'Admin Articles', 1, NULL, ''),
(18, 'Support Ticket', 1, NULL, ''),
(19, 'Admin Categories', 1, NULL, ''),
(20, 'Admin Fields', 1, NULL, ''),
(21, 'Admin Pages', 1, NULL, ''),
(22, 'Admin Settings', 1, NULL, ''),
(23, 'Admin Polls', 1, NULL, ''),
(24, 'Admin Roles', 3, '', 'roles'),
(25, 'Admin Users', 3, '', 'users'),
(26, 'Admin Articles', 3, '', ''),
(27, 'Support Ticket', 3, '', ''),
(28, 'Admin Categories', 3, '', ''),
(29, 'Admin Fields', 3, '', ''),
(30, 'Admin Pages', 3, '', ''),
(31, 'Admin Settings', 3, '', ''),
(32, 'Admin Polls', 3, '', ''),
(33, 'Admin Roles', 4, '', 'roles'),
(34, 'Admin Users', 4, '', 'users'),
(35, 'Admin Articles', 4, '', ''),
(36, 'Support Ticket', 4, '', ''),
(37, 'Admin Categories', 4, '', ''),
(38, 'Admin Fields', 4, '', ''),
(39, 'Admin Pages', 4, '', ''),
(40, 'Admin Settings', 4, '', ''),
(41, 'Admin Polls', 4, '', ''),
(42, 'Polls Plugin', 1, NULL, ''),
(43, 'Admin Files', 1, NULL, ''),
(44, 'Templates', 1, NULL, ''),
(45, 'Themes', 1, NULL, ''),
(46, 'Modules', 1, NULL, '');

-- --------------------------------------------------------

--
-- Table structure for table `permission_values`
--

CREATE TABLE IF NOT EXISTS `permission_values` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `permission_id` int(11) NOT NULL,
  `role_id` int(11) NOT NULL DEFAULT '0',
  `action_id` int(11) NOT NULL DEFAULT '0',
  `plugin` varchar(50) NOT NULL,
  `controller` varchar(50) NOT NULL,
  `pageAction` varchar(50) NOT NULL,
  `action` int(3) NOT NULL DEFAULT '0',
  `type` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=67 ;

--
-- Dumping data for table `permission_values`
--

INSERT INTO `permission_values` (`id`, `title`, `permission_id`, `role_id`, `action_id`, `plugin`, `controller`, `pageAction`, `action`, `type`) VALUES
(1, 'admin', 8, 1, 0, '', 'users', 'admin_index', 1, 'default'),
(2, 'Index', 6, 1, 0, '', 'roles', 'admin_index', 1, 'default'),
(3, 'Add', 6, 1, 0, '', 'roles', 'admin_add', 1, 'default'),
(4, 'Edit', 6, 1, 0, '', 'roles', 'admin_edit', 1, 'default'),
(5, 'Delete', 6, 1, 0, '', 'roles', 'admin_delete', 1, 'default'),
(10, 'add', 8, 1, 0, '', 'permissions', 'admin_add', 1, 'default'),
(11, 'add', 8, 1, 0, '', 'permission_values', 'admin_add', 1, 'default'),
(12, 'index', 17, 1, 0, '', 'articles', 'admin_index', 1, 'default'),
(13, 'index', 18, 1, 0, 'support_ticket', 'tickets', 'index', 1, 'default'),
(14, 'add', 17, 1, 0, '', 'articles', 'admin_add', 1, 'default'),
(15, 'edit', 17, 1, 0, '', 'articles', 'admin_edit', 1, 'default'),
(16, 'index', 19, 1, 0, '', 'categories', 'admin_index', 1, 'default'),
(17, 'index', 20, 1, 0, '', 'fields', 'admin_index', 1, 'default'),
(18, 'index', 21, 1, 0, '', 'pages', 'admin_index', 1, 'default'),
(19, 'index', 22, 1, 0, '', 'settings', 'admin_index', 1, 'default'),
(20, 'index', 23, 1, 0, '', 'polls', 'admin_index', 1, 'default'),
(21, 'edit', 21, 1, 0, '', 'pages', 'admin_edit', 1, 'default'),
(22, 'add', 21, 1, 0, '', 'pages', 'admin_add', 1, 'default'),
(23, 'delete', 21, 1, 0, '', 'pages', 'admin_delete', 1, 'default'),
(24, 'add', 22, 1, 0, '', 'settings', 'admin_add', 1, 'default'),
(25, 'edit', 22, 1, 0, '', 'settings', 'admin_edit', 1, 'default'),
(26, 'delete', 22, 1, 0, '', 'settings', 'admin_delete', 1, 'default'),
(27, 'add val', 22, 1, 0, '', 'setting_values', 'admin_add', 1, 'default'),
(28, 'edit val', 22, 1, 0, '', 'setting_values', 'admin_edit', 1, 'default'),
(29, 'add', 20, 1, 0, '', 'fields', 'admin_add', 1, 'default'),
(30, 'edit', 20, 1, 0, '', 'fields', 'admin_edit', 1, 'default'),
(31, '', 18, 1, 0, 'support_ticket', 'tickets', 'add', 1, 'default'),
(32, 'view', 17, 1, 0, '', 'articles', 'view', 1, 'default'),
(33, '', 8, 1, 0, '', 'users', 'admin_add', 1, 'default'),
(34, '', 8, 1, 0, '', 'users', 'admin_edit', 1, 'default'),
(35, 'index', 42, 1, 0, 'polls', 'polls', 'admin_index', 1, 'default'),
(36, 'add', 42, 1, 0, 'polls', 'polls', 'admin_add', 1, 'default'),
(37, 'delete', 42, 1, 0, 'polls', 'polls', 'admin_delete', 1, 'default'),
(38, 'edit', 42, 1, 0, 'polls', 'polls', 'admin_edit', 1, 'default'),
(39, 'add', 19, 1, 0, '', 'categories', 'admin_add', 1, 'default'),
(40, 'edit', 19, 1, 0, '', 'categories', 'admin_edit', 1, 'default'),
(41, 'view', 19, 1, 0, '', 'categories', 'view', 1, 'default'),
(42, 'display', 21, 1, 0, '', 'pages', 'display', 1, 'default'),
(43, 'index', 43, 1, 0, '', 'files', 'admin_index', 1, 'default'),
(44, 'add', 43, 1, 0, '', 'files', 'admin_add', 1, 'default'),
(45, 'edit', 43, 1, 0, '', 'files', 'admin_edit', 1, 'default'),
(46, 'delete', 43, 1, 0, '', 'files', 'admin_delete', 1, 'default'),
(47, 'index', 44, 1, 0, '', 'templates', 'admin_index', 1, 'default'),
(48, 'add', 44, 1, 0, '', 'templates', 'admin_add', 1, 'default'),
(49, 'edit', 44, 1, 0, '', 'templates', 'admin_edit', 1, 'default'),
(50, 'delete', 44, 1, 0, '', 'templates', 'admin_delete', 1, 'default'),
(51, 'add', 45, 1, 0, '', 'themes', 'admin_add', 1, 'default'),
(52, 'edit', 45, 1, 0, '', 'themes', 'admin_edit', 1, 'default'),
(53, 'delete', 45, 1, 0, '', 'themes', 'admin_delete', 1, 'default'),
(54, 'index', 46, 1, 0, '', 'modules', 'admin_index', 1, 'default'),
(55, 'edit', 46, 1, 0, '', 'modules', 'admin_edit', 1, 'default'),
(56, 'add', 46, 1, 0, '', 'modules', 'admin_add', 1, 'default'),
(57, 'delete', 46, 1, 0, '', 'modules', 'admin_delete', 1, 'default'),
(58, 'Step Two', 46, 1, 0, '', 'modules', 'admin_step_two', 1, 'default'),
(59, 'Step Three', 46, 1, 0, '', 'modules', 'admin_step_three', 1, 'default'),
(60, 'delete', 8, 1, 0, '', 'users', 'admin_delete', 1, 'default'),
(61, 'tag list', 17, 1, 0, '', 'articles', 'view_by_tag', 1, 'default'),
(62, 'restore', 17, 1, 0, '', 'articles', 'admin_restore', 1, 'default'),
(63, 'restore', 8, 1, 0, '', 'users', 'admin_restore', 1, 'default'),
(64, 'view', 39, 4, 0, '', 'pages', 'display', 1, 'default'),
(65, 'view', 35, 4, 0, '', 'articles', 'view', 1, 'default'),
(66, 'view', 37, 4, 0, '', 'categories', 'view', 1, 'default');

-- --------------------------------------------------------

--
-- Table structure for table `plugins`
--

CREATE TABLE IF NOT EXISTS `plugins` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) DEFAULT NULL,
  `slug` varchar(100) DEFAULT NULL,
  `description` text,
  `version` varchar(255) DEFAULT NULL,
  `author` varchar(255) DEFAULT NULL,
  `author_url` varchar(255) DEFAULT NULL,
  `plugin_url` varchar(255) DEFAULT NULL,
  `created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `deleted_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `plugin_polls`
--

CREATE TABLE IF NOT EXISTS `plugin_polls` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `article_id` int(11) DEFAULT '0',
  `title` varchar(255) DEFAULT NULL,
  `poll_type` varchar(255) DEFAULT NULL,
  `created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `deleted_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `plugin_polls`
--

INSERT INTO `plugin_polls` (`id`, `article_id`, `title`, `poll_type`, `created`, `modified`, `deleted_time`) VALUES
(5, NULL, 'Your favorite sport?', NULL, '2012-07-07 21:51:38', '2012-08-08 09:34:16', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `plugin_poll_values`
--

CREATE TABLE IF NOT EXISTS `plugin_poll_values` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `plugin_poll_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `poll_id` (`plugin_poll_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=12 ;

--
-- Dumping data for table `plugin_poll_values`
--

INSERT INTO `plugin_poll_values` (`id`, `title`, `plugin_poll_id`) VALUES
(7, 'NBA', 5),
(8, 'NHL', 5),
(9, 'PGA', 5),
(11, 'NFL', 5);

-- --------------------------------------------------------

--
-- Table structure for table `plugin_poll_voting_values`
--

CREATE TABLE IF NOT EXISTS `plugin_poll_voting_values` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `plugin_poll_id` int(11) DEFAULT '0',
  `option_id` int(11) DEFAULT '0',
  `user_id` int(11) DEFAULT '0',
  `user_ip` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `plugin_support_resources`
--

CREATE TABLE IF NOT EXISTS `plugin_support_resources` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(50) NOT NULL,
  `url` varchar(255) NOT NULL,
  `ticket_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `created` datetime NOT NULL,
  `deleted_time` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `plugin_support_tickets`
--

CREATE TABLE IF NOT EXISTS `plugin_support_tickets` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `send_user_id` int(11) NOT NULL,
  `reply_user_id` int(11) NOT NULL,
  `category` varchar(255) NOT NULL,
  `subject` varchar(255) NOT NULL,
  `message` text NOT NULL,
  `full_name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `priority` varchar(50) NOT NULL,
  `parent_id` int(11) NOT NULL,
  `created` datetime NOT NULL,
  `deleted_time` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `roles`
--

CREATE TABLE IF NOT EXISTS `roles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) DEFAULT NULL,
  `defaults` varchar(255) DEFAULT NULL,
  `created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `deleted_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `roles`
--

INSERT INTO `roles` (`id`, `title`, `defaults`, `created`, `modified`, `deleted_time`) VALUES
(1, 'admin', NULL, '0000-00-00 00:00:00', '2012-06-24 22:50:05', '0000-00-00 00:00:00'),
(3, 'member', 'default-member', '2012-06-30 15:42:06', '2012-08-15 23:26:26', '0000-00-00 00:00:00'),
(4, 'guest', 'default-guest', '2012-06-30 21:42:36', '2012-08-15 23:26:38', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `settings`
--

CREATE TABLE IF NOT EXISTS `settings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `deleted_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `settings`
--

INSERT INTO `settings` (`id`, `title`, `created`, `deleted_time`) VALUES
(1, 'Site Info', '2012-06-27 22:38:24', '0000-00-00 00:00:00'),
(2, 'Appearance', '2012-07-15 18:03:05', '0000-00-00 00:00:00'),
(3, 'Users', '2012-08-15 14:06:03', '0000-00-00 00:00:00'),
(4, 'Articles', '2012-08-17 17:04:58', '0000-00-00 00:00:00'),
(5, 'Admin', '2012-09-22 22:41:45', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `setting_values`
--

CREATE TABLE IF NOT EXISTS `setting_values` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) DEFAULT NULL,
  `description` text,
  `data` text,
  `data_options` longtext,
  `setting_type` varchar(255) DEFAULT NULL,
  `setting_id` int(11) DEFAULT '0',
  `model` varchar(255) DEFAULT NULL,
  `created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `deleted_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=24 ;

--
-- Dumping data for table `setting_values`
--

INSERT INTO `setting_values` (`id`, `title`, `description`, `data`, `data_options`, `setting_type`, `setting_id`, `model`, `created`, `modified`, `deleted_time`) VALUES
(1, 'sitename', '<p>What do you think? A site...name</p>', 'Alpha', NULL, 'text', 1, NULL, '2012-06-27 22:55:11', '2012-06-27 23:30:01', '0000-00-00 00:00:00'),
(2, 'Webmaster Email', '<p>email DUMMY - okay, sorry</p>', 'charliepage88@gmail.com', NULL, 'text', 1, NULL, '2012-06-27 23:07:12', '2012-06-27 23:30:01', '0000-00-00 00:00:00'),
(5, 'default-theme', '', '1', NULL, 'text', 2, NULL, '2012-07-15 18:03:11', '2012-09-12 23:02:01', '0000-00-00 00:00:00'),
(7, 'test', '', '', '["360","PS3"]', 'dropdown', 2, NULL, '2012-08-12 23:37:37', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(8, 'Security Question Options', '<p>Security Questions incase of lost password.</p>', '', '["What was your mothers maiden name?","Name of your first pet?","Color of your first car?","Your favorite sport?"]', 'dropdown', 3, NULL, '2012-08-15 14:08:58', '2012-08-19 23:02:13', '0000-00-00 00:00:00'),
(9, 'Security Questions', '<p>How many must a user select when signing up?</p>', '2', '["0","1","2","3"]', 'dropdown', 3, NULL, '2012-08-15 17:30:23', '2012-08-19 23:02:13', '0000-00-00 00:00:00'),
(10, 'Number of Articles on Homepage', '', '5', NULL, 'text', 4, NULL, '2012-08-17 17:08:58', '2012-10-07 21:45:12', '0000-00-00 00:00:00'),
(11, 'Categories of Articles to show on homepage', '', 'News', NULL, 'text', 4, NULL, '2012-08-17 17:12:37', '2012-10-07 21:45:12', '0000-00-00 00:00:00'),
(12, 'User Status', '<p>Choosing email activation, user must activate their account via an email link sent to them. Staff activation requires one with access to manually activate a user account.</p>', 'Staff Activation', '["Email Activation","Staff Activation"]', 'dropdown', 3, NULL, '2012-08-19 19:14:53', '2012-08-19 23:02:13', '0000-00-00 00:00:00'),
(21, 'User Register Email Subject', '', 'New Account Created', NULL, 'text', 3, NULL, '2012-08-19 21:03:07', '2012-08-19 23:02:13', '0000-00-00 00:00:00'),
(22, 'Number of Articles to list on Category Page', '', '3', NULL, 'text', 4, NULL, '2012-09-22 22:21:23', '2012-10-07 21:45:12', '0000-00-00 00:00:00'),
(23, 'Number of Items Per Page', '', '9', NULL, 'text', 5, NULL, '2012-09-22 22:41:52', '2012-09-22 23:03:56', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `templates`
--

CREATE TABLE IF NOT EXISTS `templates` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) DEFAULT NULL,
  `location` varchar(255) NOT NULL,
  `theme_id` int(11) DEFAULT '0',
  `template` text,
  `created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `deleted_time` varchar(255) DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=79 ;

--
-- Dumping data for table `templates`
--

INSERT INTO `templates` (`id`, `title`, `location`, `theme_id`, `template`, `created`, `modified`, `deleted_time`) VALUES
(14, 'Home Pages', 'Themed/Movie/Pages/home.ctp', 2, '<!-- Box -->\r\n			<div class="box">\r\n				<div class="head">\r\n					<h2>LATEST TRAILERS</h2>\r\n					<p class="text-right"><a href="#">See all</a></p>\r\n				</div>\r\n\r\n				<!-- Movie -->\r\n				<div class="movie">\r\n					\r\n					<div class="movie-image">\r\n						\r\n						<a href="#"><span class="play"><span class="name">X-MAN</span></span><img src="/themes/Movie/images/movie1.jpg" alt="movie" /></a>\r\n					</div>\r\n						\r\n					<div class="rating">\r\n						<p>RATING</p>\r\n						<div class="stars">\r\n							<div class="stars-in">\r\n								\r\n							</div>\r\n						</div>\r\n						<span class="comments">12</span>\r\n					</div>\r\n				</div>\r\n				<!-- end Movie -->\r\n				\r\n				<!-- Movie -->\r\n				<div class="movie">\r\n					<div class="movie-image">\r\n						<a href="#"><span class="play"><span class="name">SPIDER MAN 2</span></span><img src="/themes/Movie/images/movie2.jpg" alt="movie" /></a>\r\n					</div>\r\n					<div class="rating">\r\n						<p>RATING</p>\r\n						<div class="stars">\r\n							<div class="stars-in">\r\n								\r\n							</div>\r\n						</div>\r\n						<span class="comments">12</span>\r\n					</div>\r\n				</div>\r\n				<!-- end Movie -->\r\n				\r\n				<!-- Movie -->\r\n				<div class="movie">\r\n					<div class="movie-image">\r\n						<a href="#"><span class="play"><span class="name">SPIDER MAN 3</span></span><img src="/themes/Movie/images/movie3.jpg" alt="movie" /></a>\r\n					</div>\r\n					<div class="rating">\r\n						<p>RATING</p>\r\n						<div class="stars">\r\n							<div class="stars-in">\r\n								\r\n							</div>\r\n						</div>\r\n						<span class="comments">12</span>\r\n					</div>\r\n				</div>\r\n				<!-- end Movie -->\r\n				\r\n				<!-- Movie -->\r\n				<div class="movie">\r\n					<div class="movie-image">\r\n						<a href="#"><span class="play"><span class="name">VALKYRIE</span></span><img src="/themes/Movie/images/movie4.jpg" alt="movie" /></a>\r\n					</div>\r\n					<div class="rating">\r\n						<p>RATING</p>\r\n						<div class="stars">\r\n							<div class="stars-in">\r\n								\r\n							</div>\r\n						</div>\r\n						<span class="comments">12</span>\r\n					</div>\r\n				</div>\r\n				<!-- end Movie -->\r\n				\r\n				<!-- Movie -->\r\n				<div class="movie">\r\n					<div class="movie-image">\r\n						<a href="#"><span class="play"><span class="name">GLADIATOR</span></span><img src="/themes/Movie/images/movie5.jpg" alt="movie" /></a>\r\n					</div>\r\n					<div class="rating">\r\n						<p>RATING</p>\r\n						<div class="stars">\r\n							<div class="stars-in">\r\n								\r\n							</div>\r\n						</div>\r\n						<span class="comments">12</span>\r\n					</div>\r\n				</div>\r\n				<!-- end Movie -->\r\n				\r\n				<!-- Movie -->\r\n				<div class="movie last">\r\n					<div class="movie-image">\r\n						<a href="#"><span class="play"><span class="name">ICE AGE</span></span><img src="/themes/Movie/images/movie6.jpg" alt="movie" /></a>\r\n					</div>\r\n					<div class="rating">\r\n						<p>RATING</p>\r\n						<div class="stars">\r\n							<div class="stars-in">\r\n								\r\n							</div>\r\n						</div>\r\n						<span class="comments">12</span>\r\n					</div>\r\n				</div>\r\n				<!-- end Movie -->\r\n				<div class="cl">&nbsp;</div>\r\n			</div>\r\n			<!-- end Box -->\r\n			\r\n			<!-- Box -->\r\n			<div class="box">\r\n				<div class="head">\r\n					<h2>TOP RATED</h2>\r\n					<p class="text-right"><a href="#">See all</a></p>\r\n				</div>\r\n\r\n				<!-- Movie -->\r\n				<div class="movie">\r\n					<div class="movie-image">\r\n						<a href="#"><span class="play"><span class="name">TRANSFORMERS</span></span><img src="/themes/Movie/images/movie7.jpg" alt="movie" /></a>\r\n					</div>	\r\n					<div class="rating">\r\n						<p>RATING</p>\r\n						<div class="stars">\r\n							<div class="stars-in">\r\n								\r\n							</div>\r\n						</div>\r\n						<span class="comments">12</span>\r\n					</div>\r\n				</div>\r\n				<!-- end Movie -->\r\n				\r\n				<!-- Movie -->\r\n				<div class="movie">\r\n					<div class="movie-image">\r\n						<a href="#"><span class="play"><span class="name">MAGNETO</span></span><img src="/themes/Movie/images/movie8.jpg" alt="movie" /></a>\r\n					</div>\r\n					<div class="rating">\r\n						<p>RATING</p>\r\n						<div class="stars">\r\n							<div class="stars-in">\r\n								\r\n							</div>\r\n						</div>\r\n						<span class="comments">12</span>\r\n					</div>\r\n				</div>\r\n				<!-- end Movie -->\r\n				\r\n				<!-- Movie -->\r\n				<div class="movie">\r\n					<div class="movie-image">\r\n						<a href="#"><span class="play"><span class="name">KUNG FU PANDA</span></span><img src="/themes/Movie/images/movie9.jpg" alt="movie" /></a>\r\n					</div>	\r\n					<div class="rating">\r\n						<p>RATING</p>\r\n						<div class="stars">\r\n							<div class="stars-in">\r\n								\r\n							</div>\r\n						</div>\r\n						<span class="comments">12</span>\r\n					</div>\r\n				</div>\r\n				<!-- end Movie -->\r\n				\r\n				<!-- Movie -->\r\n				<div class="movie">\r\n					<div class="movie-image">\r\n						<a href="#"><span class="play"><span class="name">EAGLE EYE</span></span><img src="/themes/Movie/images/movie10.jpg" alt="movie" /></a>\r\n					</div>\r\n					<div class="rating">\r\n						<p>RATING</p>\r\n						<div class="stars">\r\n							<div class="stars-in">\r\n								\r\n							</div>\r\n						</div>\r\n						<span class="comments">12</span>\r\n					</div>\r\n				</div>\r\n				<!-- end Movie -->\r\n				\r\n				<!-- Movie -->\r\n				<div class="movie">\r\n					<div class="movie-image">\r\n						<a href="#"><span class="play"><span class="name">NARNIA</span></span><img src="/themes/Movie/images/movie11.jpg" alt="movie" /></a>\r\n					</div>\r\n					<div class="rating">\r\n						<p>RATING</p>\r\n						<div class="stars">\r\n							<div class="stars-in">\r\n								\r\n							</div>\r\n						</div>\r\n						<span class="comments">12</span>\r\n					</div>\r\n				</div>\r\n				<!-- end Movie -->\r\n				\r\n				<!-- Movie -->\r\n				<div class="movie last">\r\n					<div class="movie-image">\r\n						<a href="#"><span class="play"><span class="name">ANGELS &amp; DEMONS</span></span><img src="/themes/Movie/images/movie12.jpg" alt="movie" /></a>\r\n					</div>	\r\n					<div class="rating">\r\n						<p>RATING</p>\r\n						<div class="stars">\r\n							<div class="stars-in">\r\n								\r\n							</div>\r\n						</div>\r\n						<span class="comments">12</span>\r\n					</div>\r\n				</div>\r\n				<!-- end Movie -->\r\n				<div class="cl">&nbsp;</div>\r\n			</div>\r\n			<!-- end Box -->\r\n			\r\n			<!-- Box -->\r\n			<div class="box">\r\n				<div class="head">\r\n					<h2>MOST COMMENTED</h2>\r\n					<p class="text-right"><a href="#">See all</a></p>\r\n				</div>\r\n\r\n				<!-- Movie -->\r\n				<div class="movie">\r\n					<div class="movie-image">\r\n						<a href="#"><span class="play"><span class="name">HOUSE</span></span><img src="/themes/Movie/images/movie13.jpg" alt="movie" /></a>\r\n					</div>\r\n					<div class="rating">\r\n						<p>RATING</p>\r\n						<div class="stars">\r\n							<div class="stars-in">\r\n								\r\n							</div>\r\n						</div>\r\n						<span class="comments">12</span>\r\n					</div>\r\n				</div>\r\n				<!-- end Movie -->\r\n				\r\n				<!-- Movie -->\r\n				<div class="movie">\r\n					<div class="movie-image">\r\n						<a href="#"><span class="play"><span class="name">VACANCY</span></span><img src="/themes/Movie/images/movie14.jpg" alt="movie" /></a>\r\n					</div>	\r\n					<div class="rating">\r\n						<p>RATING</p>\r\n						<div class="stars">\r\n							<div class="stars-in">\r\n								\r\n							</div>\r\n						</div>\r\n						<span class="comments">12</span>\r\n					</div>\r\n				</div>\r\n				<!-- end Movie -->\r\n				\r\n				<!-- Movie -->\r\n				<div class="movie">\r\n					<div class="movie-image">\r\n						<a href="#"><span class="play"><span class="name">MIRRORS</span></span><img src="/themes/Movie/images/movie15.jpg" alt="movie" /></a>\r\n					</div>	\r\n					<div class="rating">\r\n						<p>RATING</p>\r\n						<div class="stars">\r\n							<div class="stars-in">\r\n								\r\n							</div>\r\n						</div>\r\n						<span class="comments">12</span>\r\n					</div>\r\n				</div>\r\n				<!-- end Movie -->\r\n				\r\n				<!-- Movie -->\r\n				<div class="movie">\r\n					<div class="movie-image">\r\n						<a href="#"><span class="play"><span class="name">THE KINGDOM</span></span><img src="/themes/Movie/images/movie16.jpg" alt="movie" /></a>\r\n					</div>	\r\n					<div class="rating">\r\n						<p>RATING</p>\r\n						<div class="stars">\r\n							<div class="stars-in">\r\n								\r\n							</div>\r\n						</div>\r\n						<span class="comments">12</span>\r\n					</div>\r\n				</div>\r\n				<!-- end Movie -->\r\n				\r\n				<!-- Movie -->\r\n				<div class="movie">\r\n					<div class="movie-image">\r\n						<a href="#"><span class="play"><span class="name">MOTIVES</span></span><img src="/themes/Movie/images/movie17.jpg" alt="movie" /></a>\r\n					</div>	\r\n					<div class="rating">\r\n						<p>RATING</p>\r\n						<div class="stars">\r\n							<div class="stars-in">\r\n								\r\n							</div>\r\n						</div>\r\n						<span class="comments">12</span>\r\n					</div>\r\n				</div>\r\n				<!-- end Movie -->\r\n				\r\n				<!-- Movie -->\r\n 				<div class="movie last">\r\n 					<div class="movie-image">\r\n						<a href="#"><span class="play"><span class="name">THE PRESTIGE</span></span><img src="/themes/Movie/images/movie18.jpg" alt="movie" /></a>\r\n					</div>	\r\n					<div class="rating">\r\n						<p>RATING</p>\r\n						<div class="stars">\r\n							<div class="stars-in">\r\n								\r\n							</div>\r\n						</div>\r\n						<span class="comments">12</span>\r\n					</div>\r\n				</div>\r\n				<!-- end Movie -->\r\n				<div class="cl">&nbsp;</div>\r\n			</div>\r\n			<!-- end Box -->\r\n</div>\r\n\r\n		<!-- NEWS -->\r\n		<div id="news">\r\n			<div class="head">\r\n				<h3>NEWS</h3>\r\n				<p class="text-right"><a href="#">See all</a></p>\r\n			</div>\r\n			<?php foreach($this->request->data as $row): ?>\r\n				<div class="content">\r\n					<p class="date">\r\n						<?= $this->Time->format(''F jS, Y h:i A'',\r\n						 $row[''Article''][''created'']) ?>\r\n					</p>\r\n					<h4><?= $row[''Article''][''title''] ?></h4>\r\n					<p>Test Test</p>\r\n					<?= $this->Html->link(''Read More'', array(''controller'' => ''articles'', ''action'' => ''view'', $row[''Article''][''slug''])); ?>\r\n				</div>\r\n			<?php endforeach ?>\r\n		</div>\r\n		<!-- end NEWS -->\r\n		\r\n		<!-- Coming -->\r\n		<div id="coming">\r\n			<div class="head">\r\n				<h3>COMING SOON<strong>!</strong></h3>\r\n				<p class="text-right"><a href="#">See all</a></p>\r\n			</div>\r\n			<div class="content">\r\n				<h4>The Princess and the Frog </h4>\r\n					<a href="#"><img src="/themes/Movie/images/coming-soon1.jpg" alt="coming soon" /></a>\r\n				<p>Walt Disney Animation Studios presents the musical "The Princess and the Frog," an animated comedy set in the great city of New Orleans...</p>\r\n				<a href="#">Read more</a>\r\n			</div>\r\n			<div class="cl">&nbsp;</div>\r\n			<div class="content">\r\n				<h4>The Princess and the Frog </h4>\r\n					<a href="#"><img src="/themes/Movie/images/coming-soon2.jpg" alt="coming soon" /></a>\r\n				<p>Walt Disney Animation Studios presents the musical "The Princess and the Frog," an animated comedy set in the great city of New Orleans...</p>\r\n				<a href="#">Read more</a>\r\n			</div>\r\n			\r\n		<!-- end Coming -->', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(13, 'Display Pages', 'Themed/Movie/Pages/display.ctp', 2, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(12, 'Default Layouts', 'Themed/Movie/Layouts/default.ctp', 2, '<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">\r\n<html lang="en-US" xmlns="http://www.w3.org/1999/xhtml" dir="ltr">\r\n<head>\r\n	<title>\r\n		<?php echo $title_for_layout; ?>\r\n	</title>\r\n	<meta http-equiv="Content-type" content="text/html; charset=utf-8" />\r\n	<link rel="stylesheet" href="/themes/Movie/css/style.css" type="text/css" media="all" />\r\n	<!--[if IE 6]>\r\n		<link rel="stylesheet" href="/themes/Movie/css/ie6.css" type="text/css" media="all" />\r\n	<![endif]-->\r\n	<?php\r\n		echo $this->fetch(''meta'');\r\n    	echo $this->fetch(''css'');\r\n    	echo $this->fetch(''script'');\r\n	?>\r\n	<!-- <link href="<?= $this->webroot ?>css/bootstrap.css" rel="stylesheet"> -->\r\n	<!-- <link href="<?= $this->webroot ?>css/bootstrap-responsive.css" rel="stylesheet"> -->\r\n    <?php if (1 == 1): ?>\r\n    <?= $this->Html->script(''jquery.min.js'') ?>\r\n    <?php else: ?>\r\n    <?= $this->Html->script(''//ajax.googleapis.com/ajax/libs/jquery/1.7.2/jquery.min.js'') ?>\r\n    <?php endif; ?>\r\n\r\n    <?= $this->Html->script(''bootstrap.min.js'') ?>\r\n\r\n    <?php if (1 == 1): ?>\r\n    <?= $this->Html->script(''jquery.validate.min.js'') ?>\r\n    <?php else: ?>\r\n    <?= $this->Html->script(''//ajax.aspnetcdn.com/ajax/jquery.validate/1.9/jquery.validate.min.js'') ?>\r\n    <?php endif; ?>\r\n\r\n    <script type="text/javascript" src="/themes/Movie/js/jquery-func.js"></script>\r\n</head>\r\n<body>\r\n<!-- Shell -->\r\n<div id="shell">\r\n	<!-- Header -->\r\n	<div id="header">\r\n		<h1 id="logo"><a href="#">Movie Hunter</a></h1>\r\n		<div class="social">\r\n			<span>FOLLOW US ON:</span>\r\n			<ul>\r\n			    <li><a class="twitter" href="#">twitter</a></li>\r\n			    <li><a class="facebook" href="#">facebook</a></li>\r\n			    <li><a class="vimeo" href="#">vimeo</a></li>\r\n			    <li><a class="rss" href="#">rss</a></li>\r\n			</ul>\r\n		</div>\r\n		\r\n		<!-- Navigation -->\r\n		<div id="navigation">\r\n			<ul>\r\n			    <li><a class="active" href="/">HOME</a></li>\r\n			    <li><a href="/category/news/">NEWS</a></li>\r\n			    <li><a href="#">IN THEATERS</a></li>\r\n			    <li><a href="#">COMING SOON</a></li>\r\n			    <li><a href="/pages/contact-us/">CONTACT</a></li>\r\n			    <li><a href="/pages/advertise/">ADVERTISE</a></li>\r\n			</ul>\r\n		</div>\r\n		<!-- end Navigation -->\r\n		\r\n		<!-- Sub-menu -->\r\n		<div id="sub-navigation">\r\n			<ul>\r\n			    <li><a href="#">SHOW ALL</a></li>\r\n			    <li><a href="#">LATEST TRAILERS</a></li>\r\n			    <li><a href="#">TOP RATED</a></li>\r\n			    <li><a href="#">MOST COMMENTED</a></li>\r\n			</ul>\r\n			<div id="search">\r\n				<form action="home_submit" method="get" accept-charset="utf-8">\r\n					<label for="search-field">SEARCH</label>					\r\n					<input type="text" name="search field" value="Enter search here" id="search-field" title="Enter search here" class="blink search-field"  />\r\n					<input type="submit" value="GO!" class="search-button" />\r\n				</form>\r\n			</div>\r\n		</div>\r\n		<!-- end Sub-Menu -->\r\n		\r\n	</div>\r\n	<!-- end Header -->\r\n	\r\n	<!-- Main -->\r\n	<div id="main">\r\n		<!-- Content -->\r\n		<div id="content">\r\n			<?php echo $this->Session->flash(); ?>\r\n			<?php echo $this->fetch(''content''); ?>\r\n		</div>\r\n		<!-- end Content -->\r\n		<?php\r\n			// echo $this->element(''sql_dump'')\r\n		?>\r\n		<div class="cl">&nbsp;</div>\r\n	</div>\r\n	<!-- end Main -->\r\n\r\n	<!-- Footer -->\r\n	<div id="footer">\r\n		<p>\r\n			<a href="/">HOME</a> <span>|</span>\r\n			<a href="/category/news">NEWS</a> <span>|</span>\r\n			<a href="#">IN THEATERS</a> <span>|</span>\r\n			<a href="#">COMING SOON </a> <span>|</span>\r\n			<a href="#">LATERS TRAILERS</a> <span>|</span>\r\n			<a href="#">TOP RATED TRAILERS</a> <span>|</span>\r\n			<a href="#">MOST COMMENTED TRAILERS</a> <span>|</span>\r\n			<a href="/pages/advertise/">ADVERTISE</a> <span>|</span>\r\n			<a href="/pages/contact-us/">CONTACT </a>\r\n		</p>\r\n		<p> &copy; <a href="http://www.insanevisions.com" target="_blank">InsaneVisions</a> 2007-2012  <?php echo $this->Html->link(\r\n          $this->Html->image(''cake.power.gif'', array(''border'' => ''0'')),\r\n          ''http://www.cakephp.org/'',\r\n          array(''target'' => ''_blank'', ''escape'' => false)\r\n        );\r\n      ?>  Designed by <a href="http://chocotemplates.com" target="_blank" title="The Sweetest CSS Templates WorldWide">ChocoTemplates.com</a></p>\r\n	</div>\r\n	<!-- end Footer -->\r\n</div>\r\n<!-- end Shell -->\r\n</body>\r\n</html>', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(11, 'View Articles', 'Themed/Movie/Articles/view.ctp', 2, '<div class="box">\r\n	<h1><?= $this->request->data[''Article''][''title''] ?></h1>\r\n\r\n	posted by: <?= $this->request->data[''User''][''username''] ?><br />\r\n	at: <?= $this->Time->format(''F jS, Y h:i A'', $this->request->data[''Article''][''created'']) ?><br />\r\n	category: <?= $this->request->data[''Category''][''title''] ?>\r\n\r\n	<?php foreach($this->request->data[''ArticleValue''] as $data): ?>\r\n	<p><?= $data[''Field''][''title''] ?>: \r\n		<?php if (is_array(json_decode($data[''data'']))): ?>\r\n			<?= debug(json_decode($data[''data''])) ?>\r\n		<?php else: ?>\r\n			<?= $data[''data''] ?>\r\n		<?php endif ?>\r\n	</p>\r\n	<?php endforeach; ?>\r\n</div>', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(15, 'Admin Add Articles', 'Articles/admin_add.ctp', 1, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(16, 'Admin Edit Articles', 'Articles/admin_edit.ctp', 1, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(17, 'Admin Index Articles', 'Articles/admin_index.ctp', 1, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(18, 'View Articles', 'Articles/view.ctp', 1, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(19, 'Admin Add Categories', 'Categories/admin_add.ctp', 1, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(20, 'Admin Edit Categories', 'Categories/admin_edit.ctp', 1, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(21, 'Admin Index Categories', 'Categories/admin_index.ctp', 1, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(22, 'View Categories', 'Categories/view.ctp', 1, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(23, 'Plugins Sidebar Elements', 'Elements/plugins_sidebar.ctp', 1, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(24, 'Sidebar Elements', 'Elements/sidebar.ctp', 1, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(25, 'Default html', 'Emails/html/default.ctp', 1, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(26, 'Default text', 'Emails/text/default.ctp', 1, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(27, 'Error400 Errors', 'Errors/error400.ctp', 1, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(28, 'Error500 Errors', 'Errors/error500.ctp', 1, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(29, 'Admin Add Fields', 'Fields/admin_add.ctp', 1, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(30, 'Admin Edit Fields', 'Fields/admin_edit.ctp', 1, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(31, 'Admin Index Fields', 'Fields/admin_index.ctp', 1, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(32, 'Admin Add Files', 'Files/admin_add.ctp', 1, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(33, 'Admin Edit Files', 'Files/admin_edit.ctp', 1, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(34, 'Admin Index Files', 'Files/admin_index.ctp', 1, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(35, 'Html Emails', 'Layouts/Emails/html', 1, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(36, 'Text Emails', 'Layouts/Emails/text', 1, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(37, 'Admin Layouts', 'Layouts/admin.ctp', 1, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(38, 'Ajax Layouts', 'Layouts/ajax.ctp', 1, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(39, 'Default Layouts', 'Layouts/default.ctp', 1, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(40, 'Error Layouts', 'Layouts/error.ctp', 1, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(41, 'Flash Layouts', 'Layouts/flash.ctp', 1, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(42, 'Default js', 'Layouts/js/default.ctp', 1, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(43, 'Default rss', 'Layouts/rss/default.ctp', 1, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(44, 'Default xml', 'Layouts/xml/default.ctp', 1, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(45, 'Admin Index Modules', 'Modules/admin_index.ctp', 1, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(46, 'Admin Pages', 'Pages/admin.ctp', 1, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(47, 'Admin Add Pages', 'Pages/admin_add.ctp', 1, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(48, 'Admin Edit Pages', 'Pages/admin_edit.ctp', 1, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(49, 'Admin Index Pages', 'Pages/admin_index.ctp', 1, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(50, 'Denied Pages', 'Pages/denied.ctp', 1, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(51, 'Display Pages', 'Pages/display.ctp', 1, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(52, 'Home Pages', 'Pages/home.ctp', 1, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(53, 'Admin Add Roles', 'Roles/admin_add.ctp', 1, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(54, 'Admin Edit Roles', 'Roles/admin_edit.ctp', 1, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(55, 'Admin Index Roles', 'Roles/admin_index.ctp', 1, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(56, 'Admin Add Settings', 'Settings/admin_add.ctp', 1, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(57, 'Admin Edit Settings', 'Settings/admin_edit.ctp', 1, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(58, 'Admin Index Settings', 'Settings/admin_index.ctp', 1, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(59, 'Admin Add Templates', 'Templates/admin_add.ctp', 1, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(60, 'Admin Edit Templates', 'Templates/admin_edit.ctp', 1, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(61, 'Admin Index Templates', 'Templates/admin_index.ctp', 1, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(62, 'Admin Add Themes', 'Themes/admin_add.ctp', 1, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(63, 'Admin Edit Themes', 'Themes/admin_edit.ctp', 1, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(64, 'Admin Add Users', 'Users/admin_add.ctp', 1, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(65, 'Admin Edit Users', 'Users/admin_edit.ctp', 1, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(66, 'Admin Index Users', 'Users/admin_index.ctp', 1, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(67, 'Ajax Check User Users', 'Users/ajax_check_user.ctp', 1, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(68, 'Login Users', 'Users/login.ctp', 1, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(69, 'Register Users', 'Users/register.ctp', 1, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(70, 'Admin Add Modules', 'Modules/admin_add.ctp', 1, NULL, '2012-08-19 17:49:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(71, 'Admin Step Three Modules', 'Modules/admin_step_three.ctp', 1, NULL, '2012-08-19 17:49:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(72, 'Admin Step Two Modules', 'Modules/admin_step_two.ctp', 1, NULL, '2012-08-19 17:49:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(76, 'movies', 'Articles/movies.ctp', 1, 'specific movie page yi', '2012-10-07 22:52:16', '2012-10-07 22:52:29', '0000-00-00 00:00:00'),
(75, 'news', 'Themed/Movie/Categories/news.ctp', 2, 'heys', '2012-10-07 22:30:20', '2012-10-07 22:31:44', '0000-00-00 00:00:00'),
(77, 'latest_articles', 'Elements/latest_articles.ctp', 1, 'test', '2012-10-12 23:26:15', '2012-10-12 23:26:30', '0000-00-00 00:00:00'),
(78, 'poll_show', 'Elements/poll_show.ctp', 1, 'showing a poll', '2012-10-13 23:19:44', '2012-10-13 23:20:05', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `themes`
--

CREATE TABLE IF NOT EXISTS `themes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) DEFAULT NULL,
  `created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `deleted_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=31 ;

--
-- Dumping data for table `themes`
--

INSERT INTO `themes` (`id`, `title`, `created`, `modified`, `deleted_time`) VALUES
(2, 'Movie', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(1, 'Default', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `role_id` int(11) DEFAULT '0',
  `login_time` varchar(255) DEFAULT NULL,
  `security_answers` longtext NOT NULL,
  `settings` longtext NOT NULL,
  `status` int(3) DEFAULT '0',
  `theme_id` int(11) DEFAULT '0',
  `created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `deleted_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `last_reset_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=12 ;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `password`, `email`, `role_id`, `login_time`, `security_answers`, `settings`, `status`, `theme_id`, `created`, `modified`, `deleted_time`, `last_reset_time`) VALUES
(4, 'guest', 'f6fda68a7e08e3b9c3fccf24ed666097a8c2676d', 'guest@google.com', 4, '2012-08-19 22:58:10', '', '', 0, 0, '2012-07-01 15:30:08', '2012-08-19 22:58:10', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(7, 'admin', 'c823d0a95cdf74ccfc6cc083ecfc3196c462ab16', 'charliepage88@gmail.com', 1, '2012-10-14 19:21:07', '{"1":{"question":"What was your mother''s maiden name?","answer":"elizabeth"},"2":{"question":"Color of your first car?","answer":"Silver"}}', '', 1, 0, '2012-07-15 15:11:45', '2012-10-14 19:21:07', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(9, 'testing', 'c823d0a95cdf74ccfc6cc083ecfc3196c462ab16', 'charliepage88+test@gmail.com', 3, '2012-08-15 23:29:35', '{"1":{"question":"What was your mother''s maiden name?","answer":"adsads"},"2":{"question":"Color of your first car?","answer":"red"},"0":{"activate_code":"ec8803ff29e998cb6401972c9b38f069"}}', '', 1, 0, '2012-08-15 23:29:35', '2012-09-12 22:13:59', '0000-00-00 00:00:00', '0000-00-00 00:00:00');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
