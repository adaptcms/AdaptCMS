var BaseClass = new Class({

});