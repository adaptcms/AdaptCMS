//= require "base_class"
var Template = new Class({

});
