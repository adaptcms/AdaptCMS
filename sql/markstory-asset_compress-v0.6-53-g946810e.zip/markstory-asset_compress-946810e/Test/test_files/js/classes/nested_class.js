//= require "base_class_two"
// Remove me
// remove me too
var NestedClass = BaseClassTwo.extend({

});