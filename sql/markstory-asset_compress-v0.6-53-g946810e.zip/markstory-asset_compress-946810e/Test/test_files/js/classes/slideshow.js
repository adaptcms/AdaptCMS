//= require <library_file>
//= require <secondary/another_class>
var Slideshow = new Class({

});