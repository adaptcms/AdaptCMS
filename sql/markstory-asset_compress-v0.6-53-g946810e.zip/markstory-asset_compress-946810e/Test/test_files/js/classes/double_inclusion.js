//= require "base_class_two.js"
//= require "base_class"
var DoubleInclusion = new Class({

});