//= require "base_class"
var BaseClassTwo = BaseClass.extend({

});