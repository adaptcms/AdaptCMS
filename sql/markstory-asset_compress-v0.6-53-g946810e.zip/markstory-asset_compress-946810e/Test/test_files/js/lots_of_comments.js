/*!
Important comment
*/
// this
//
// file has
//     lots of
//
// Comments
//   They should
//
All
// Not be here
be
// any
// more/
not
// \/\ test
here
/******
multi line comments
*/
	/* should be erased */
/*
None of these
*/
	/** Should *****/
/*
be
here
anymore
*****/