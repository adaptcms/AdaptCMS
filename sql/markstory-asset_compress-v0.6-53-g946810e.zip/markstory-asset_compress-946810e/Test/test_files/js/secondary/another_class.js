var AnotherClass = Class.extend({

});