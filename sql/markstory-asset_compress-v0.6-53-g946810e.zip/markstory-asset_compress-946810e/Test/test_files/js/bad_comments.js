/* COMMENT
MORE
MORE WITH NO *
MORE
MORE*/
(function($){function Foo(){this.bar=[];}})

//     	 COMMENT
function something() {
	return 1 + 1;
}
		   	/*
the next
valid
close */
function two() {
	return 1 + 1;
}